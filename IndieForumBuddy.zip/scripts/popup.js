document.getElementById('report').addEventListener('click', () => {
    alert('Feature under construction!');
  });
  